package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.Exception.EmployeeNotFoundException;
import com.cts.model.Employee;
import com.cts.model.Skill;
import com.cts.service.skillService;
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/employee")
public class skillcontroller {

	@Autowired
	skillService skillservice;
	@GetMapping(value="/showallemployee")
	public List<Employee> showallempl()
	{
		System.out.println("Controller called");
		return skillservice.getemployeeList();
	}
	@GetMapping(value="/deleteemployeebyId/{id}")
	public String deleteEmpl(@PathVariable("id") int id) throws EmployeeNotFoundException
	{
		System.out.println("Controller called");
		return skillservice.deleteEmployeeById(id);
	}
	@GetMapping(value="/getemployeebyId/{id}")
	public Employee getEmpl(@PathVariable("id") int id) throws EmployeeNotFoundException
	{
		System.out.println("Controller called");
		return skillservice.getEmployeeById(id);
	}
	@PostMapping(value="/addemployee")
	public Employee addempl(@RequestBody Employee empl) throws EmployeeNotFoundException
	{
		return skillservice.addEmployee(empl);
	}
	@PostMapping(value="/updateemployee")
	public Employee updateempl(@RequestBody Employee empl) throws EmployeeNotFoundException
	{
		return skillservice.updateEmployee(empl);
	}
	@PostMapping(value="/addemployeetechskill/{id}")
	public Employee addemptechskill(@PathVariable("id") int id,@RequestBody Skill skill) throws EmployeeNotFoundException
	{
		return skillservice.addEmployeeTechSkillById(id, skill);
	}
	@PostMapping(value="/addemployeenontechskill/{id}")
	public Employee addempnontechskill(@PathVariable("id") int id,@RequestBody Skill skill) throws EmployeeNotFoundException
	{
		return skillservice.addEmployeeNonTechSkillById(id, skill);
	}
	@PostMapping(value="/deleteemployeetechskill/{id}")
	public Employee deleteemptechskill(@PathVariable("id") int id,@RequestBody Skill skill) throws EmployeeNotFoundException
	{
		return skillservice.deleteEmployeeTechSkillById(id, skill);
	}
	@PostMapping(value="/deleteemployeenontechskill/{id}")
	public Employee deleteempnontechskill(@PathVariable("id") int id,@RequestBody Skill skill) throws EmployeeNotFoundException
	{
		return skillservice.deleteEmployeeNonTechSkillById(id, skill);
	}
}
