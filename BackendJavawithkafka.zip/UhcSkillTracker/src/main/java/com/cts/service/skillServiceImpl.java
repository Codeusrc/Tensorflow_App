package com.cts.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.cts.Exception.EmployeeNotFoundException;
import com.cts.model.Employee;
import com.cts.model.KafkaResponse;
import com.cts.model.Skill;
import com.cts.repo.employeeRepo;
@Service
public class skillServiceImpl implements skillService {
	@Autowired
	employeeRepo employeeRepository;
	@Autowired
	private KafkaTemplate<String,Object> template;
	@Autowired
	private KafkaResponse responsekafka;
	private String topic="UHG_SkillTracker";

	@Override
	public List<Employee> getemployeeList() {
		// TODO Auto-generated method stub
		System.out.println("Employee called");
		List<Employee> empList=employeeRepository.findAll();
		responsekafka.setResponseCode(HttpStatus.ACCEPTED);
		responsekafka.setResponseDescription("Status Recieved Ok");
		responsekafka.setTimeStamp(LocalDateTime.now());
		template.send(topic,responsekafka);
		return empList;
	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		return employeeRepository.findById(id)
				.orElseThrow(
				()->new EmployeeNotFoundException("Employee with the empId "+id+" doen't exists"));
		
	}
	@Override
	public Employee addEmployee(Employee e) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		int id=e.getEmployeeId();
		Optional<Employee> empl=employeeRepository.findById(id);
		if(empl.isPresent())
		{
			responsekafka.setResponseCode(HttpStatus.BAD_REQUEST);
			responsekafka.setResponseDescription("Status Recieved Bad Request");
			responsekafka.setTimeStamp(LocalDateTime.now());
			template.send(topic,responsekafka);
			throw new EmployeeNotFoundException("Employeee already exists");
		}
		else
		{
			responsekafka.setResponseCode(HttpStatus.ACCEPTED);
			responsekafka.setResponseDescription("Status Recieved Ok");
			responsekafka.setTimeStamp(LocalDateTime.now());
			template.send(topic,responsekafka);
			employeeRepository.save(e);
			return e;
			
		}
		
	}
	

	@Override
	public String deleteEmployeeById(int id) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		Optional<Employee> empl=employeeRepository.findById(id);
		if(!empl.isPresent())
		{
			responsekafka.setResponseCode(HttpStatus.BAD_REQUEST);
			responsekafka.setResponseDescription("Status Recieved Bad Request");
			responsekafka.setTimeStamp(LocalDateTime.now());
			template.send(topic,responsekafka);
			throw new EmployeeNotFoundException("Employeee doesnot exist");
		}
		else
		{
			employeeRepository.deleteById(id);
			responsekafka.setResponseCode(HttpStatus.ACCEPTED);
			responsekafka.setResponseDescription("Status Recieved Ok");
			responsekafka.setTimeStamp(LocalDateTime.now());
			template.send(topic,responsekafka);
			return "Employee Deleted Successfully";
		}
	}

	
	@Override
	public Employee updateEmployee(Employee eid) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		Optional<Employee> empl=employeeRepository.findById(eid.getEmployeeId());
		if(!empl.isPresent())
		{
			responsekafka.setResponseCode(HttpStatus.BAD_REQUEST);
			responsekafka.setResponseDescription("Status Recieved Bad Request");
			responsekafka.setTimeStamp(LocalDateTime.now());
			template.send(topic,responsekafka);
			throw new EmployeeNotFoundException("Employee doesnot exist");
		}
		else
		{
			Employee emplo=empl.get();
			emplo.setEmployeeName(eid.getEmployeeName());
			emplo.setEmployeeDepartment(eid.getEmployeeDepartment());
			emplo.setEmployeeDOB(eid.getEmployeeDOB());
			emplo.setNonTechnicalSkillList(eid.getNonTechnicalSkillList());
			emplo.setTechnicalSkillList(eid.getTechnicalSkillList());
			employeeRepository.save(emplo);
			responsekafka.setResponseCode(HttpStatus.ACCEPTED);
			responsekafka.setResponseDescription("Status Recieved Ok");
			responsekafka.setTimeStamp(LocalDateTime.now());
			template.send(topic,responsekafka);
			return emplo;
		}
	
	}

	@Override
	public Employee addEmployeeTechSkillById(int id, Skill skill) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub

		Optional<Employee> empl=employeeRepository.findById(id);
		System.out.println(id);
		if(!empl.isPresent())
		{
			responsekafka.setResponseCode(HttpStatus.BAD_REQUEST);
			responsekafka.setResponseDescription("Status Recieved Bad Request");
			responsekafka.setTimeStamp(LocalDateTime.now());
			template.send(topic,responsekafka);
			throw new EmployeeNotFoundException("Employee doesnot exist");
		}
		else
		{
			int y=0;
			Employee emplo=empl.get();
			List<Skill> sk=new ArrayList<>();
			sk.addAll(emplo.getTechnicalSkillList());
			for(Skill skl:sk)
			{
				if(skl.getSkillName().equalsIgnoreCase(skill.getSkillName()))
				{
					skl.setCompetancyValue(skill.getCompetancyValue());
					y=1;
				}
			}
			if(y==0) {
			sk.add(skill);
			emplo.setTechnicalSkillList(sk);
			}
			employeeRepository.save(emplo);
			responsekafka.setResponseCode(HttpStatus.ACCEPTED);
			responsekafka.setResponseDescription("Status Recieved Ok");
			responsekafka.setTimeStamp(LocalDateTime.now());
			template.send(topic,responsekafka);
			return emplo;
		}
		
	}
	@Override
	public Employee addEmployeeNonTechSkillById(int id, Skill skill) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		Optional<Employee> empl=employeeRepository.findById(id);
		if(!empl.isPresent())
		{
			responsekafka.setResponseCode(HttpStatus.BAD_REQUEST);
			responsekafka.setResponseDescription("Status Recieved Bad Request");
			responsekafka.setTimeStamp(LocalDateTime.now());
			template.send(topic,responsekafka);
			throw new EmployeeNotFoundException("Employee doesnot exist");
		}
		else
		{
			int g=0;
			Employee emplo=empl.get();
			List<Skill> sk=new ArrayList<>();
			sk.addAll(emplo.getNonTechnicalSkillList());
			for(Skill skj:sk)
			{
				if(skj.getSkillName().equalsIgnoreCase(skill.getSkillName()))
				{
					skj.setCompetancyValue(skill.getCompetancyValue());
					g=1;
				}
			}
			if(g==0) {
			sk.add(skill);
			emplo.setNonTechnicalSkillList(sk);
			}
			employeeRepository.save(emplo);
			responsekafka.setResponseCode(HttpStatus.ACCEPTED);
			responsekafka.setResponseDescription("Status Recieved Ok");
			responsekafka.setTimeStamp(LocalDateTime.now());
			template.send(topic,responsekafka);
			return emplo;
		}
		
	}

	@Override
	public Employee deleteEmployeeTechSkillById(int id, Skill skill) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		Optional<Employee> empl=employeeRepository.findById(id);
		if(!empl.isPresent())
		{
			responsekafka.setResponseCode(HttpStatus.BAD_REQUEST);
			responsekafka.setResponseDescription("Status Recieved Bad Request");
			responsekafka.setTimeStamp(LocalDateTime.now());
			template.send(topic,responsekafka);
			throw new EmployeeNotFoundException("Employee doesnot exist");
		}
		else
		{
			Employee emplo=empl.get();
			List<Skill> techremove=emplo.getTechnicalSkillList();
			ListIterator<Skill> iter=techremove.listIterator();
			while(iter.hasNext())
			{
				if(iter.next().getSkillName().equalsIgnoreCase(skill.getSkillName()))
				{
					iter.remove();
				}
			}
			employeeRepository.save(emplo);
			responsekafka.setResponseCode(HttpStatus.ACCEPTED);
			responsekafka.setResponseDescription("Status Recieved Ok");
			responsekafka.setTimeStamp(LocalDateTime.now());
			template.send(topic,responsekafka);
			return emplo;
		}
		
	}

	@Override
	public Employee deleteEmployeeNonTechSkillById(int id, Skill skill) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		Optional<Employee> empl=employeeRepository.findById(id);
		if(!empl.isPresent())
		{
			responsekafka.setResponseCode(HttpStatus.BAD_REQUEST);
			responsekafka.setResponseDescription("Status Recieved Bad Request");
			responsekafka.setTimeStamp(LocalDateTime.now());
			template.send(topic,responsekafka);
			throw new EmployeeNotFoundException("Employee doesnot exist");
		}
		else
		{
			Employee emplo=empl.get();
			List<Skill> nontechremove=emplo.getNonTechnicalSkillList();
			ListIterator<Skill> iter=nontechremove.listIterator();
			while(iter.hasNext())
			{
				if(iter.next().getSkillName().equalsIgnoreCase(skill.getSkillName()))
				{
					iter.remove();
				}
			}
			employeeRepository.save(emplo);
			responsekafka.setResponseCode(HttpStatus.ACCEPTED);
			responsekafka.setResponseDescription("Status Recieved Ok");
			responsekafka.setTimeStamp(LocalDateTime.now());
			template.send(topic,responsekafka);
			return emplo;
		}
	}
	

}
