package com.cts.model;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="employee")
public class Employee {
	@Id
	private int employeeId;
	private String employeeName;
	private Date employeeDOB;
	private String employeeDepartment;
	private List<Skill> technicalSkillList;
	private List<Skill> nonTechnicalSkillList;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Date getEmployeeDOB() {
		return employeeDOB;
	}
	public void setEmployeeDOB(Date employeeDOB) {
		this.employeeDOB = employeeDOB;
	}
	public String getEmployeeDepartment() {
		return employeeDepartment;
	}
	public void setEmployeeDepartment(String employeeDepartment) {
		this.employeeDepartment = employeeDepartment;
	}
	public List<Skill> getTechnicalSkillList() {
		return technicalSkillList;
	}
	public void setTechnicalSkillList(List<Skill> technicalSkillList) {
		this.technicalSkillList = technicalSkillList;
	}
	public List<Skill> getNonTechnicalSkillList() {
		return nonTechnicalSkillList;
	}
	public void setNonTechnicalSkillList(List<Skill> nonTechnicalSkillList) {
		this.nonTechnicalSkillList = nonTechnicalSkillList;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int employeeId, String employeeName, Date employeeDOB, String employeeDepartment,
			List<Skill> technicalSkillList, List<Skill> nonTechnicalSkillList) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeDOB = employeeDOB;
		this.employeeDepartment = employeeDepartment;
		this.technicalSkillList = technicalSkillList;
		this.nonTechnicalSkillList = nonTechnicalSkillList;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeDOB=" + employeeDOB
				+ ", employeeDepartment=" + employeeDepartment + ", technicalSkillList=" + technicalSkillList
				+ ", nonTechnicalSkillList=" + nonTechnicalSkillList + "]";
	}
	
	

}
