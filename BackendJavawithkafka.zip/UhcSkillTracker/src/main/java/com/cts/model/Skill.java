package com.cts.model;

public class Skill {
	private String skillName;
	private int competancyValue;
	public String getSkillName() {
		return skillName;
	}
	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}
	public int getCompetancyValue() {
		return competancyValue;
	}
	public void setCompetancyValue(int competancyValue) {
		this.competancyValue = competancyValue;
	}
	public Skill(String skillName, int competancyValue) {
		super();
		this.skillName = skillName;
		this.competancyValue = competancyValue;
	}
	public Skill() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Skill [skillName=" + skillName + ", competancyValue=" + competancyValue + "]";
	}
	

}
